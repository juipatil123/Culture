// Render Projects View - Card-based layout with detailed information
const renderProjectsView = () => (
    <>
        {/* Projects Grid - Card View */}
        <div className="row g-4 mb-4">
            {managedProjects.length > 0 ? (
                managedProjects.map(project => {
                    // Calculate Duration
                    const startDate = project.startDate ? new Date(project.startDate) : new Date();
                    const dueDate = project.dueDate ? new Date(project.dueDate) : new Date();
                    const diffTime = Math.abs(dueDate - startDate);
                    const durationDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                    // Count Members (People working on project)
                    const memberCount = project.assignedMembers ? project.assignedMembers.length : 0;

                    // Count Devices (if available in project data)
                    const deviceCount = project.devices ? project.devices.length : (project.deviceCount || 0);

                    // Project ID
                    const pId = project.id || project._id;

                    // Meetings Count from state
                    const meetingsCount = projectMeetings[pId] || 0;

                    // Requirement Count
                    const reqCount = (projectRequirements[pId] || []).length;

                    return (
                        <div key={project.id || project._id} className="col-12 col-lg-6 col-xl-4">
                            <div className="card border-0 shadow-sm h-100 hover-lift" style={{ transition: 'transform 0.2s' }}
                                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-5px)'}
                                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}>

                                {/* Card Header */}
                                <div className="card-header bg-gradient-primary text-white py-3" style={{
                                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                                }}>
                                    <div className="d-flex justify-content-between align-items-start">
                                        <div className="flex-grow-1">
                                            <h5 className="mb-1 fw-bold text-white">{project.name || 'Unnamed Project'}</h5>
                                            <small className="text-white-50">
                                                <i className="fas fa-building me-1"></i>
                                                {project.client || project.clientName || 'No Client'}
                                            </small>
                                        </div>
                                        <span className={`badge ${((project.status || project.projectStatus || '').toLowerCase() === 'completed') ? 'bg-success' :
                                                ((project.status || project.projectStatus || '').toLowerCase() === 'in progress') ? 'bg-info' :
                                                    'bg-warning text-dark'
                                            }`}>
                                            {project.status || project.projectStatus || 'Active'}
                                        </span>
                                    </div>
                                </div>

                                {/* Card Body - Project Details */}
                                <div className="card-body">
                                    {/* Project Description */}
                                    {project.description && (
                                        <p className="text-muted small mb-3" style={{
                                            display: '-webkit-box',
                                            WebkitLineClamp: 2,
                                            WebkitBoxOrient: 'vertical',
                                            overflow: 'hidden'
                                        }}>
                                            {project.description}
                                        </p>
                                    )}

                                    {/* Key Metrics Grid */}
                                    <div className="row g-2 mb-3">
                                        {/* People Working */}
                                        <div className="col-6">
                                            <div className="p-3 bg-primary bg-opacity-10 rounded-3 text-center">
                                                <div className="d-flex align-items-center justify-content-center mb-1">
                                                    <i className="fas fa-users text-primary me-2"></i>
                                                    <h4 className="mb-0 fw-bold text-primary">{memberCount}</h4>
                                                </div>
                                                <small className="text-muted fw-semibold">Team Members</small>
                                            </div>
                                        </div>

                                        {/* Devices Involved */}
                                        <div className="col-6">
                                            <div className="p-3 bg-info bg-opacity-10 rounded-3 text-center">
                                                <div className="d-flex align-items-center justify-content-center mb-1">
                                                    <i className="fas fa-laptop text-info me-2"></i>
                                                    <h4 className="mb-0 fw-bold text-info">{deviceCount}</h4>
                                                </div>
                                                <small className="text-muted fw-semibold">Devices</small>
                                            </div>
                                        </div>

                                        {/* Meetings Organized */}
                                        <div className="col-6">
                                            <div className="p-3 bg-success bg-opacity-10 rounded-3 text-center">
                                                <div className="d-flex align-items-center justify-content-center mb-1">
                                                    <i className="fas fa-video text-success me-2"></i>
                                                    <h4 className="mb-0 fw-bold text-success">{meetingsCount}</h4>
                                                </div>
                                                <small className="text-muted fw-semibold">Meetings</small>
                                                <button
                                                    className="btn btn-sm btn-success mt-1 w-100"
                                                    onClick={() => handleRecordMeeting(pId)}
                                                    title="Record new meeting"
                                                >
                                                    <i className="fas fa-plus me-1"></i>Add Meeting
                                                </button>
                                            </div>
                                        </div>

                                        {/* Duration */}
                                        <div className="col-6">
                                            <div className="p-3 bg-warning bg-opacity-10 rounded-3 text-center">
                                                <div className="d-flex align-items-center justify-content-center mb-1">
                                                    <i className="far fa-clock text-warning me-2"></i>
                                                    <h4 className="mb-0 fw-bold text-warning">{durationDays}</h4>
                                                </div>
                                                <small className="text-muted fw-semibold">Days Duration</small>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Project Timeline */}
                                    <div className="mb-3">
                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                            <small className="text-muted">
                                                <i className="fas fa-calendar-alt me-1"></i>
                                                {project.startDate ? new Date(project.startDate).toLocaleDateString() : 'N/A'}
                                            </small>
                                            <small className="text-muted">
                                                <i className="fas fa-flag-checkered me-1"></i>
                                                {project.dueDate || project.endDate ? new Date(project.dueDate || project.endDate).toLocaleDateString() : 'N/A'}
                                            </small>
                                        </div>
                                        {project.progress !== undefined && (
                                            <div className="progress" style={{ height: '8px' }}>
                                                <div
                                                    className="progress-bar bg-gradient-primary"
                                                    style={{ width: `${project.progress}%` }}
                                                    role="progressbar"
                                                ></div>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                {/* Card Footer - Action Buttons */}
                                <div className="card-footer bg-light border-0 py-3">
                                    <div className="d-grid gap-2">
                                        <button
                                            className="btn btn-primary position-relative"
                                            onClick={() => {
                                                setActiveProjectForRequirement(project);
                                                setShowRequirementModal(true);
                                            }}
                                        >
                                            <i className="fas fa-clipboard-list me-2"></i>
                                            View Requirements
                                            {reqCount > 0 && (
                                                <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                                    {reqCount}
                                                </span>
                                            )}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })
            ) : (
                <div className="col-12">
                    <div className="card border-0 shadow-sm">
                        <div className="card-body text-center py-5">
                            <i className="fas fa-folder-open fa-3x text-muted mb-3 opacity-50"></i>
                            <h5 className="text-muted">No Projects Found</h5>
                            <p className="text-muted mb-0">No projects are currently assigned to your team.</p>
                        </div>
                    </div>
                </div>
            )}
        </div>

        {/* Requirements Modal - Notes Format */}
        {showRequirementModal && activeProjectForRequirement && (
            <div className="modal fade show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 1060 }}>
                <div className="modal-dialog modal-lg">
                    <div className="modal-content border-0 shadow-lg">
                        <div className="modal-header border-0 pb-0" style={{
                            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                        }}>
                            <div className="text-white">
                                <h5 className="modal-title fw-bold mb-1">
                                    <i className="fas fa-clipboard-list me-2"></i>
                                    Project Requirements
                                </h5>
                                <small className="opacity-75">{activeProjectForRequirement.name}</small>
                            </div>
                            <button type="button" className="btn-close btn-close-white" onClick={() => {
                                setShowRequirementModal(false);
                                setEditingRequirement(null);
                                setRequirementText('');
                            }}></button>
                        </div>

                        <div className="modal-body p-4">
                            {/* Add New Requirement Section */}
                            <div className="mb-4 p-4 bg-light rounded-3">
                                <label className="form-label fw-bold text-primary mb-3">
                                    <i className="fas fa-plus-circle me-2"></i>
                                    {editingRequirement ? 'Update Requirement' : 'Add New Requirement'}
                                </label>
                                <textarea
                                    className="form-control border-2 shadow-sm mb-3"
                                    rows="4"
                                    value={requirementText}
                                    onChange={(e) => setRequirementText(e.target.value)}
                                    placeholder="Enter requirement details, specifications, or changes needed for this project..."
                                    style={{ resize: 'none' }}
                                ></textarea>
                                <div className="d-flex gap-2">
                                    <button
                                        className={`btn ${editingRequirement ? 'btn-success' : 'btn-primary'} flex-grow-1 shadow-sm`}
                                        onClick={handleSaveRequirement}
                                        disabled={!requirementText.trim()}
                                    >
                                        <i className={`fas ${editingRequirement ? 'fa-save' : 'fa-plus'} me-2`}></i>
                                        {editingRequirement ? 'Update Requirement' : 'Add Requirement'}
                                    </button>
                                    {editingRequirement && (
                                        <button
                                            className="btn btn-outline-secondary"
                                            onClick={() => {
                                                setEditingRequirement(null);
                                                setRequirementText('');
                                            }}
                                        >
                                            <i className="fas fa-times me-1"></i>Cancel
                                        </button>
                                    )}
                                </div>
                            </div>

                            {/* Requirements List - Notes Format */}
                            <div>
                                <div className="d-flex justify-content-between align-items-center mb-3">
                                    <h6 className="fw-bold mb-0">
                                        <i className="fas fa-list-ul me-2 text-primary"></i>
                                        All Requirements
                                    </h6>
                                    <span className="badge bg-primary">{(projectRequirements[activeProjectForRequirement.id || activeProjectForRequirement._id] || []).length} Total</span>
                                </div>

                                <div className="requirements-notes-list" style={{ maxHeight: '400px', overflowY: 'auto' }}>
                                    {(projectRequirements[activeProjectForRequirement.id || activeProjectForRequirement._id] || []).length > 0 ? (
                                        (projectRequirements[activeProjectForRequirement.id || activeProjectForRequirement._id] || [])
                                            .slice().reverse()
                                            .map((req, index) => (
                                                <div
                                                    key={req.id}
                                                    className={`card mb-3 border-start border-4 ${editingRequirement?.id === req.id ? 'border-primary shadow' : 'border-secondary'}`}
                                                    style={{ transition: 'all 0.2s' }}
                                                >
                                                    <div className="card-body p-3">
                                                        {/* Note Header */}
                                                        <div className="d-flex justify-content-between align-items-start mb-2">
                                                            <div className="flex-grow-1">
                                                                <div className="d-flex align-items-center gap-2 mb-1">
                                                                    <span className="badge bg-secondary">#{(projectRequirements[activeProjectForRequirement.id || activeProjectForRequirement._id] || []).length - index}</span>
                                                                    <small className="text-muted">
                                                                        <i className="far fa-calendar-alt me-1"></i>
                                                                        {new Date(req.date).toLocaleDateString('en-US', {
                                                                            month: 'short',
                                                                            day: 'numeric',
                                                                            year: 'numeric',
                                                                            hour: '2-digit',
                                                                            minute: '2-digit'
                                                                        })}
                                                                    </small>
                                                                </div>
                                                                {req.updatedAt && (
                                                                    <small className="text-info d-block">
                                                                        <i className="fas fa-edit me-1"></i>
                                                                        Last updated: {new Date(req.updatedAt).toLocaleString('en-US', {
                                                                            month: 'short',
                                                                            day: 'numeric',
                                                                            hour: '2-digit',
                                                                            minute: '2-digit'
                                                                        })}
                                                                    </small>
                                                                )}
                                                            </div>
                                                            <div className="d-flex gap-1">
                                                                <button
                                                                    className="btn btn-sm btn-outline-primary"
                                                                    onClick={() => handleEditRequirement(req)}
                                                                    title="Edit Requirement"
                                                                >
                                                                    <i className="fas fa-edit"></i>
                                                                </button>
                                                                <span className="badge bg-warning text-dark align-self-start">Pending</span>
                                                            </div>
                                                        </div>

                                                        {/* Note Content */}
                                                        <div className="requirement-note-content p-3 bg-light rounded" style={{ whiteSpace: 'pre-wrap' }}>
                                                            {req.text}
                                                        </div>
                                                    </div>
                                                </div>
                                            ))
                                    ) : (
                                        <div className="text-center py-5">
                                            <i className="fas fa-clipboard fa-3x text-muted mb-3 opacity-25"></i>
                                            <h6 className="text-muted">No Requirements Added Yet</h6>
                                            <p className="text-muted small mb-0">Add your first requirement using the form above</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="modal-footer border-0 bg-light">
                            <button type="button" className="btn btn-secondary px-4" onClick={() => {
                                setShowRequirementModal(false);
                                setEditingRequirement(null);
                                setRequirementText('');
                            }}>
                                <i className="fas fa-times me-2"></i>Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )}
    </>
);
